package org.java;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class App extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/org/java/ResearchLabManager.fxml"));
        Parent root = loader.load();

        stage.setTitle("Research Lab Manager");
        stage.setScene(new Scene(root, 1080, 720));
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
