package org.java;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.layout.GridPane;
import javafx.geometry.Insets;
import javafx.scene.control.ComboBox;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class LabManagerController {

    // ---------- DB connection (same defaults as DB.java) ----------
    private static final String DB_URL = "jdbc:sqlserver://localhost:1433;databaseName=ResearchLabManager;encrypt=true;trustServerCertificate=true;";
    private static final String DB_USER = "sa";
    private static final String DB_PASS = "YourStrongPassword123!";

    private Connection conn;
    private LabManagerDAO dao;

    // ---------- Top / bottom ----------
    @FXML private Label connectionStatusLabel;
    @FXML private Label footerLabel;

    // ---------- Tab 1: Projects & Members ----------
    @FXML private TableView<LabMember> memberTable;
    @FXML private TableColumn<LabMember, Number> memberIdCol;
    @FXML private TableColumn<LabMember, String> memberFirstCol;
    @FXML private TableColumn<LabMember, String> memberLastCol;
    @FXML private TableColumn<LabMember, String> memberJoinCol;

    @FXML private TableView<ResearchProject> projectTable;
    @FXML private TableColumn<ResearchProject, Number> projectIdCol;
    @FXML private TableColumn<ResearchProject, String> projectTitleCol;
    @FXML private TableColumn<ResearchProject, String> projectStatusCol;
    @FXML private TableColumn<ResearchProject, String> projectMembersCol;

    @FXML private TextField projectStatusIdField;
    @FXML private Label projectStatusResultLabel;
    @FXML private TextField grantIdField;
    @FXML private TextArea projectsOutputArea;


    // ---------- Tab 2: Equipment ----------
    @FXML private TableView<Equipment> equipmentTable;
    @FXML private TableColumn<Equipment, ?> equipIdCol;
    @FXML private TableColumn<Equipment, ?> equipModelCol;
    @FXML private TableColumn<Equipment, ?> equipTypeCol;
    @FXML private TableColumn<Equipment, ?> equipStatusCol;

    @FXML private TableView<EquipmentUsage> usageTable;
    @FXML private TableColumn<EquipmentUsage, ?> usageIdCol;
    @FXML private TableColumn<EquipmentUsage, ?> usageMemberCol;
    @FXML private TableColumn<EquipmentUsage, ?> usageDeviceCol;
    @FXML private TableColumn<EquipmentUsage, ?> usagePurposeCol;

    @FXML private TextField deviceStatusIdField;
    @FXML private Label deviceStatusResultLabel;
    @FXML private TextField deviceUsersIdField;
    @FXML private TextArea equipmentOutputArea;

    // ---------- Tab 3: Reporting ----------
    @FXML private DatePicker endedBeforeDatePicker;
    @FXML private TextArea reportingOutputArea;

    // ============================================================
    // Lifecycle
    // ============================================================
    @FXML
    public void initialize() {
        wireMemberColumns();
        wireProjectColumns();
        wireEquipmentColumns();
        wireUsageColumns();
        connectToDatabase();
    }

    private void wireMemberColumns() {
        memberIdCol.setCellValueFactory(new PropertyValueFactory<>("memberId"));
        memberFirstCol.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        memberLastCol.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        memberJoinCol.setCellValueFactory(new PropertyValueFactory<>("joinDate"));
    }

    private void wireProjectColumns() {
        projectIdCol.setCellValueFactory(new PropertyValueFactory<>("projectId"));
        projectTitleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        projectStatusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
        projectMembersCol.setCellValueFactory(new PropertyValueFactory<>("memberIds"));
    }

    private void wireEquipmentColumns() {
        equipIdCol.setCellValueFactory(new PropertyValueFactory<>("equipmentId"));
        equipModelCol.setCellValueFactory(new PropertyValueFactory<>("modelName"));
        equipTypeCol.setCellValueFactory(new PropertyValueFactory<>("type"));
        equipStatusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
    }



    private void wireUsageColumns() {
        usageIdCol.setCellValueFactory(new PropertyValueFactory<>("usageId"));
        usageMemberCol.setCellValueFactory(new PropertyValueFactory<>("memberId"));
        usageDeviceCol.setCellValueFactory(new PropertyValueFactory<>("deviceNumber"));
        usagePurposeCol.setCellValueFactory(new PropertyValueFactory<>("purpose"));
    }

    private void connectToDatabase() {
        try {
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
            dao = new LabManagerDAO(conn);
            connectionStatusLabel.setText("Connected to " + DB_URL);
        } catch (SQLException e) {
            connectionStatusLabel.setText("DB connection failed: " + e.getMessage());
        }
    }

    // ============================================================
    // Tab 1 - Project & Member Management
    // ============================================================

    @FXML
    private void onRefreshMembers() {
        if (!ensureDao(projectsOutputArea)) return;
        try {
            List<LabMember> members = dao.listMembers();
            ObservableList<LabMember> data = FXCollections.observableArrayList(members);
            memberTable.setItems(data);
            appendOutput(projectsOutputArea, "Loaded " + members.size() + " members.");
        } catch (SQLException e) {
            error(projectsOutputArea, e);
        }
    }

    @FXML
    private void onAddMember() {
        if (!ensureDao(projectsOutputArea)) return;

        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Add Lab Member");
        dialog.setHeaderText("Enter new member details");

        ButtonType addButtonType = new ButtonType("Add", ButtonType.OK.getButtonData());
        dialog.getDialogPane().getButtonTypes().addAll(addButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField firstNameField = new TextField();
        firstNameField.setPromptText("First name");
        TextField lastNameField = new TextField();
        lastNameField.setPromptText("Last name");
        DatePicker joinDatePicker = new DatePicker();
        joinDatePicker.setPromptText("Join date");

        grid.add(new Label("First name:"), 0, 0);
        grid.add(firstNameField,          1, 0);
        grid.add(new Label("Last name:"), 0, 1);
        grid.add(lastNameField,           1, 1);
        grid.add(new Label("Join date:"), 0, 2);
        grid.add(joinDatePicker,          1, 2);

        dialog.getDialogPane().setContent(grid);

        // Enable/disable Add button depending on required fields
        var addButton = dialog.getDialogPane().lookupButton(addButtonType);
        addButton.disableProperty().bind(
            firstNameField.textProperty().isEmpty()
                    .or(lastNameField.textProperty().isEmpty())
                    .or(joinDatePicker.valueProperty().isNull())
        );

        dialog.setResultConverter(button -> {
            if (button == addButtonType) {
                try {
                    dao.addMember(
                            firstNameField.getText().trim(),
                            lastNameField.getText().trim(),
                            joinDatePicker.getValue()
                    );
                    appendOutput(projectsOutputArea, "Member added: " +
                            firstNameField.getText().trim() + " " +
                            lastNameField.getText().trim());
                    onRefreshMembers();
                } catch (SQLException e) {
                    error(projectsOutputArea, e);
                }
            }
            return null;
        });

        dialog.showAndWait();
    }

    @FXML
    private void onUpdateMember() {
        if (!ensureDao(projectsOutputArea)) return;

        LabMember selected = memberTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            appendOutput(projectsOutputArea, "Select a member to update.");
            return;
        }

        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Update Lab Member");
        dialog.setHeaderText("Edit member details (ID: " + selected.getMemberId() + ")");

        ButtonType saveButtonType = new ButtonType("Save", ButtonType.OK.getButtonData());
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField firstNameField = new TextField(selected.getFirstName());
        TextField lastNameField  = new TextField(selected.getLastName());

        // parse joinDate string into LocalDate if possible
        LocalDate joinDate = null;
        try {
            if (selected.getJoinDate() != null && !selected.getJoinDate().isBlank()) {
                joinDate = LocalDate.parse(selected.getJoinDate());
            }
        } catch (Exception ignored) {}
        DatePicker joinDatePicker = new DatePicker(joinDate);

        grid.add(new Label("First name:"), 0, 0);
        grid.add(firstNameField,          1, 0);
        grid.add(new Label("Last name:"), 0, 1);
        grid.add(lastNameField,           1, 1);
        grid.add(new Label("Join date:"), 0, 2);
        grid.add(joinDatePicker,          1, 2);

        dialog.getDialogPane().setContent(grid);

        var saveButton = dialog.getDialogPane().lookupButton(saveButtonType);
        saveButton.disableProperty().bind(
                firstNameField.textProperty().isEmpty()
                        .or(lastNameField.textProperty().isEmpty())
                        .or(joinDatePicker.valueProperty().isNull())
        );

        dialog.setResultConverter(button -> {
            if (button == saveButtonType) {
                try {
                    dao.updateMember(
                            selected.getMemberId(),
                            firstNameField.getText().trim(),
                            lastNameField.getText().trim(),
                            joinDatePicker.getValue()
                    );
                    appendOutput(projectsOutputArea,
                            "Member " + selected.getMemberId() + " updated.");
                    onRefreshMembers();
                } catch (SQLException e) {
                    error(projectsOutputArea, e);
                }
            }
            return null;
        });

        dialog.showAndWait();
    }

    @FXML
private void onRemoveMember() {
    if (!ensureDao(projectsOutputArea)) return;

    LabMember selected = memberTable.getSelectionModel().getSelectedItem();
    if (selected == null) {
        appendOutput(projectsOutputArea, "Select a member to remove.");
        return;
    }

    Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
            "Remove member ID " + selected.getMemberId() + " (" +
                    selected.getFirstName() + " " + selected.getLastName() + ")?",
            ButtonType.OK, ButtonType.CANCEL);
    confirm.setHeaderText("Confirm Member Removal");
    confirm.showAndWait();

    if (confirm.getResult() != ButtonType.OK) {
        return;
    }

    try {
        dao.deleteMember(selected.getMemberId());
        appendOutput(projectsOutputArea, "Member " + selected.getMemberId() + " removed.");
        onRefreshMembers();
    } catch (SQLException e) {
        error(projectsOutputArea, e);
    }
}


    @FXML private void onRefreshProjects() {
        if (!ensureDao(projectsOutputArea)) return;
        try {
            List<ResearchProject> projects = dao.listProjects();
            ObservableList<ResearchProject> data = FXCollections.observableArrayList(projects);
            projectTable.setItems(data);
            appendOutput(equipmentOutputArea, "Loaded " + projects.size() + " projects.");
        } catch (SQLException e) {
            error(projectsOutputArea, e);
        }
    }

    private String joinIds(List<Integer> ids) {
        if (ids == null || ids.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < ids.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(ids.get(i));
        }
        return sb.toString();
    }

    private List<Integer> parseMemberIdList(String raw) {
        List<Integer> ids = new java.util.ArrayList<>();
        if (raw == null || raw.isBlank()) {
            return ids;
        }
        String[] parts = raw.split(",");
        for (String p : parts) {
            String trimmed = p.trim();
            if (trimmed.isEmpty()) continue;
            try {
                ids.add(Integer.parseInt(trimmed));
            } catch (NumberFormatException ignored) {
                // silently skip invalid tokens; could log to output area if you like
            }
        }
        return ids;
    }

    @FXML
    private void onAddProject() {
        if (!ensureDao(projectsOutputArea)) return;

        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Add Research Project");
        dialog.setHeaderText("Enter new project details");

        ButtonType addButtonType = new ButtonType("Add", ButtonType.OK.getButtonData());
        dialog.getDialogPane().getButtonTypes().addAll(addButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField titleField = new TextField();
        titleField.setPromptText("Project title");

        ComboBox<String> statusBox = new ComboBox<>();
        statusBox.getItems().addAll("Planned", "Active", "On Hold", "Completed");
        statusBox.setPromptText("Select status");

        TextField memberIdsField = new TextField();
        memberIdsField.setPromptText("e.g. 1, 2, 5");

        grid.add(new Label("Title:"),       0, 0);
        grid.add(titleField,                1, 0);
        grid.add(new Label("Status:"),      0, 1);
        grid.add(statusBox,                 1, 1);
        grid.add(new Label("Member IDs:"),  0, 2);
        grid.add(memberIdsField,            1, 2);

        dialog.getDialogPane().setContent(grid);

        var addButton = dialog.getDialogPane().lookupButton(addButtonType);
        addButton.disableProperty().bind(
                titleField.textProperty().isEmpty()
                        .or(statusBox.valueProperty().isNull())
        );

        dialog.setResultConverter(button -> {
            if (button == addButtonType) {
                try {
                    // 1) Create project
                    int projectId = dao.addProject(
                            titleField.getText().trim(),
                            statusBox.getValue()
                    );

                    // 2) Parse and save members in WorksOn
                    List<Integer> memberIds = parseMemberIdList(memberIdsField.getText());
                    dao.setProjectMembers(projectId, memberIds);

                    appendOutput(projectsOutputArea,
                            "Project added: " + titleField.getText().trim() +
                            " (ID=" + projectId + ", " + statusBox.getValue() + ")");
                    onRefreshProjects();
                } catch (SQLException e) {
                    error(projectsOutputArea, e);
                }
            }
            return null;
        });

        dialog.showAndWait();
    }



    @FXML
    private void onUpdateProject() {
        if (!ensureDao(projectsOutputArea)) return;

        ResearchProject selected = projectTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            appendOutput(projectsOutputArea, "Select a project to update.");
            return;
        }

        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Update Project");
        dialog.setHeaderText("Edit project (ID: " + selected.getProjectId() + ")");

        ButtonType saveButtonType = new ButtonType("Save", ButtonType.OK.getButtonData());
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField titleField = new TextField(selected.getTitle());

        ComboBox<String> statusBox = new ComboBox<>();
        statusBox.getItems().addAll("Planned", "Active", "On Hold", "Completed");
        statusBox.setValue(selected.getStatus());

        TextField memberIdsField = new TextField();
        try {
            List<Integer> currentIds = dao.getMemberIdsForProject(selected.getProjectId());
            memberIdsField.setText(joinIds(currentIds));
        } catch (SQLException e) {
            // If it fails, just leave blank and log error
            appendOutput(projectsOutputArea,
                    "Could not load members for project " + selected.getProjectId() +
                    ": " + e.getMessage());
        }
        memberIdsField.setPromptText("e.g. 1, 2, 5");

        grid.add(new Label("Title:"),       0, 0);
        grid.add(titleField,                1, 0);
        grid.add(new Label("Status:"),      0, 1);
        grid.add(statusBox,                 1, 1);
        grid.add(new Label("Member IDs:"),  0, 2);
        grid.add(memberIdsField,            1, 2);

        dialog.getDialogPane().setContent(grid);

        var saveButton = dialog.getDialogPane().lookupButton(saveButtonType);
        saveButton.disableProperty().bind(
                titleField.textProperty().isEmpty()
                        .or(statusBox.valueProperty().isNull())
        );

        dialog.setResultConverter(button -> {
            if (button == saveButtonType) {
                try {
                    // 1) Update the project fields
                    dao.updateProject(
                            selected.getProjectId(),
                            titleField.getText().trim(),
                            statusBox.getValue()
                    );

                    // 2) Replace project members in WorksOn
                    List<Integer> memberIds = parseMemberIdList(memberIdsField.getText());
                    dao.setProjectMembers(selected.getProjectId(), memberIds);

                    appendOutput(projectsOutputArea,
                            "Project " + selected.getProjectId() +
                            " updated; members set to: " + memberIdsField.getText());
                    onRefreshProjects();
                } catch (SQLException e) {
                    error(projectsOutputArea, e);
                }
            }
            return null;
        });

        dialog.showAndWait();
    }





    @FXML
private void onRemoveProject() {
    if (!ensureDao(projectsOutputArea)) return;

    ResearchProject selected = projectTable.getSelectionModel().getSelectedItem();
    if (selected == null) {
        appendOutput(projectsOutputArea, "Select a project to remove.");
        return;
    }

    Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
            "Remove project ID " + selected.getProjectId() + " (" +
                    selected.getTitle() + ")?",
            ButtonType.OK, ButtonType.CANCEL);
    confirm.setHeaderText("Confirm Project Removal");
    confirm.showAndWait();

    if (confirm.getResult() != ButtonType.OK) {
        return;
    }

    try {
        dao.deleteProject(selected.getProjectId());
        appendOutput(projectsOutputArea, "Project " + selected.getProjectId() + " removed.");
        onRefreshProjects();
    } catch (SQLException e) {
        error(projectsOutputArea, e);
    }
}


    @FXML
    private void onShowProjectStatus() {
        if (!ensureDao(projectsOutputArea)) return;
        Integer id = parseInt(projectStatusIdField.getText(), projectsOutputArea, "Project ID");
        if (id == null) return;
        try {
            String status = dao.getProjectStatus(id);
            projectStatusResultLabel.setText("Status: " + status);
            appendOutput(projectsOutputArea, "Project " + id + " status: " + status);
        } catch (SQLException e) {
            error(projectsOutputArea, e);
        }
    }

    @FXML
    private void onShowMembersByGrant() {
        if (!ensureDao(projectsOutputArea)) return;
        Integer id = parseInt(grantIdField.getText(), projectsOutputArea, "Grant ID");
        if (id == null) return;
        try {
            List<String> members = dao.getMembersByGrant(id);
            projectsOutputArea.clear();
            appendOutput(projectsOutputArea, "Members for grant #" + id + ":");
            if (members.isEmpty()) {
                appendOutput(projectsOutputArea, "  (none)");
            } else {
                members.forEach(name -> appendOutput(projectsOutputArea, "  - " + name));
            }
        } catch (SQLException e) {
            error(projectsOutputArea, e);
        }
    }

    

    @FXML
    private void onShowMentorship() {
        runWithStdoutCapture(projectsOutputArea, () -> dao.printMentorshipByProject());
    }

    // ============================================================
    // Tab 2 - Equipment Usage Tracking
    // ============================================================

    @FXML private void onRefreshEquipment() {         
        if (!ensureDao(projectsOutputArea)) return;
        try {
            List<Equipment> equipments = dao.listEquipments();
            ObservableList<Equipment> data = FXCollections.observableArrayList(equipments);
            equipmentTable.setItems(data);
            appendOutput(equipmentOutputArea, "Loaded " + equipments.size() + " equipments.");
        } catch (SQLException e) {
            error(projectsOutputArea, e);
        } 
    }

    @FXML
    private void onAddEquipment() {
        if (!ensureDao(equipmentOutputArea)) return;

        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Add Equipment");
        dialog.setHeaderText("Enter new equipment details");

        ButtonType addButtonType = new ButtonType("Add", ButtonType.OK.getButtonData());
        dialog.getDialogPane().getButtonTypes().addAll(addButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField nameField = new TextField();
        nameField.setPromptText("Model / Name");

        TextField typeField = new TextField();
        typeField.setPromptText("Type (e.g., Microscope)");

        ComboBox<String> statusBox = new ComboBox<>();
        statusBox.getItems().addAll("Available", "In Use", "Maintenance", "Retired");
        statusBox.setPromptText("Select status");

        grid.add(new Label("Name:"),   0, 0);
        grid.add(nameField,            1, 0);
        grid.add(new Label("Type:"),   0, 1);
        grid.add(typeField,            1, 1);
        grid.add(new Label("Status:"), 0, 2);
        grid.add(statusBox,            1, 2);

        dialog.getDialogPane().setContent(grid);

        var addButton = dialog.getDialogPane().lookupButton(addButtonType);
        addButton.disableProperty().bind(
                nameField.textProperty().isEmpty()
                        .or(typeField.textProperty().isEmpty())
                        .or(statusBox.valueProperty().isNull())
        );

        dialog.setResultConverter(button -> {
            if (button == addButtonType) {
                try {
                    dao.addEquipment(
                            nameField.getText().trim(),
                            typeField.getText().trim(),
                            statusBox.getValue()
                    );
                    appendOutput(equipmentOutputArea,
                            "Equipment added: " + nameField.getText().trim());
                    onRefreshEquipment();
                } catch (SQLException e) {
                    error(equipmentOutputArea, e);
                }
            }
            return null;
        });

        dialog.showAndWait();
    }

    @FXML
    private void onUpdateEquipment() {
        if (!ensureDao(equipmentOutputArea)) return;

        Equipment selected = equipmentTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            appendOutput(equipmentOutputArea, "Select equipment to update.");
            return;
        }

        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Update Equipment");
        dialog.setHeaderText("Edit equipment (ID: " + selected.getEquipmentId() + ")");

        ButtonType saveButtonType = new ButtonType("Save", ButtonType.OK.getButtonData());
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField nameField = new TextField(selected.getModelName());
        TextField typeField = new TextField(selected.getType());

        ComboBox<String> statusBox = new ComboBox<>();
        statusBox.getItems().addAll("Available", "In Use", "Maintenance", "Retired");
        statusBox.setValue(selected.getStatus());

        grid.add(new Label("Name:"),   0, 0);
        grid.add(nameField,            1, 0);
        grid.add(new Label("Type:"),   0, 1);
        grid.add(typeField,            1, 1);
        grid.add(new Label("Status:"), 0, 2);
        grid.add(statusBox,            1, 2);

        dialog.getDialogPane().setContent(grid);

        var saveButton = dialog.getDialogPane().lookupButton(saveButtonType);
        saveButton.disableProperty().bind(
                nameField.textProperty().isEmpty()
                        .or(typeField.textProperty().isEmpty())
                        .or(statusBox.valueProperty().isNull())
        );

        dialog.setResultConverter(button -> {
            if (button == saveButtonType) {
                try {
                    dao.updateEquipment(
                        selected.getEquipmentId(),                
                        nameField.getText().trim(),              
                        typeField.getText().trim(),              
                        statusBox.getValue()                 
                    );
                    appendOutput(equipmentOutputArea,
                            "Equipment " + selected.getEquipmentId() + " updated.");
                    onRefreshEquipment();
                } catch (SQLException e) {
                    error(equipmentOutputArea, e);
                }
            }
            return null;
        });

        dialog.showAndWait();
    }

    @FXML
private void onRemoveEquipment() {
    if (!ensureDao(equipmentOutputArea)) return;

    Equipment selected = equipmentTable.getSelectionModel().getSelectedItem();
    if (selected == null) {
        appendOutput(equipmentOutputArea, "Select equipment to remove.");
        return;
    }

    Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
            "Remove device #" + selected.getEquipmentId() +
                    " (" + selected.getModelName() + ")?",
            ButtonType.OK, ButtonType.CANCEL);
    confirm.setHeaderText("Confirm Equipment Removal");
    confirm.showAndWait();

    if (confirm.getResult() != ButtonType.OK) {
        return;
    }

    try {
        dao.deleteEquipment(selected.getEquipmentId()); // DeviceNumber
        appendOutput(equipmentOutputArea,
                "Equipment (device #" + selected.getEquipmentId() + ") removed.");
        onRefreshEquipment();
    } catch (SQLException e) {
        error(equipmentOutputArea, e);
    }
}


    @FXML private void onRefreshUsage() { 
        if (!ensureDao(projectsOutputArea)) return;
        try {
            List<EquipmentUsage> equipmentUsages = dao.listEquipmentUsages();
            ObservableList<EquipmentUsage> data = FXCollections.observableArrayList(equipmentUsages);
            usageTable.setItems(data);
            appendOutput(equipmentOutputArea, "Loaded " + equipmentUsages.size() + " equipments.");
        } catch (SQLException e) {
            error(projectsOutputArea, e);
        } 
     }

    @FXML
    private void onAddUsage() {
        if (!ensureDao(equipmentOutputArea)) return;

        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Add Equipment Usage");
        dialog.setHeaderText("Register new equipment usage");

        ButtonType addButtonType = new ButtonType("Add", ButtonType.OK.getButtonData());
        dialog.getDialogPane().getButtonTypes().addAll(addButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField memberIdField  = new TextField();
        TextField deviceNumField = new TextField();
        TextField purposeField   = new TextField();

        memberIdField.setPromptText("Member ID");
        deviceNumField.setPromptText("Device #");
        purposeField.setPromptText("Purpose");

        grid.add(new Label("Member ID:"),  0, 0);
        grid.add(memberIdField,           1, 0);
        grid.add(new Label("Device #:"),  0, 1);
        grid.add(deviceNumField,          1, 1);
        grid.add(new Label("Purpose:"),   0, 2);
        grid.add(purposeField,            1, 2);

        dialog.getDialogPane().setContent(grid);

        var addButton = dialog.getDialogPane().lookupButton(addButtonType);
        addButton.disableProperty().bind(
                memberIdField.textProperty().isEmpty()
                        .or(deviceNumField.textProperty().isEmpty())
                        .or(purposeField.textProperty().isEmpty())
        );

        dialog.setResultConverter(button -> {
            if (button == addButtonType) {
                try {
                    int memberId  = Integer.parseInt(memberIdField.getText().trim());
                    int deviceNum = Integer.parseInt(deviceNumField.getText().trim());

                    dao.addEquipmentUsage(
                            memberId,
                            deviceNum,
                            purposeField.getText().trim()
                    );
                    appendOutput(equipmentOutputArea,
                            "Usage added for member " + memberId + " on device " + deviceNum);
                    onRefreshUsage();
                } catch (NumberFormatException e) {
                    appendOutput(equipmentOutputArea, "Member ID and Device # must be numbers.");
                } catch (SQLException e) {
                    error(equipmentOutputArea, e);
                }
            }
            return null;
        });

        dialog.showAndWait();
    }

    @FXML
    private void onUpdateUsage() {
        if (!ensureDao(equipmentOutputArea)) return;

        EquipmentUsage selected = usageTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            appendOutput(equipmentOutputArea, "Select a usage record to update.");
            return;
        }

        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Update Equipment Usage");
        dialog.setHeaderText("Edit usage (ID: " + selected.getUsageId() + ")");

        ButtonType saveButtonType = new ButtonType("Save", ButtonType.OK.getButtonData());
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField memberIdField  = new TextField(String.valueOf(selected.getMemberId()));
        TextField deviceNumField = new TextField(String.valueOf(selected.getDeviceNumber()));
        TextField purposeField   = new TextField(selected.getPurpose());

        grid.add(new Label("Member ID:"),  0, 0);
        grid.add(memberIdField,           1, 0);
        grid.add(new Label("Device #:"),  0, 1);
        grid.add(deviceNumField,          1, 1);
        grid.add(new Label("Purpose:"),   0, 2);
        grid.add(purposeField,            1, 2);

        dialog.getDialogPane().setContent(grid);

        var saveButton = dialog.getDialogPane().lookupButton(saveButtonType);
        saveButton.disableProperty().bind(
                memberIdField.textProperty().isEmpty()
                        .or(deviceNumField.textProperty().isEmpty())
                        .or(purposeField.textProperty().isEmpty())
        );

        dialog.setResultConverter(button -> {
            if (button == saveButtonType) {
                try {
                    int memberId  = Integer.parseInt(memberIdField.getText().trim());
                    int deviceNum = Integer.parseInt(deviceNumField.getText().trim());

                    dao.updateEquipmentUsage(
                            selected.getUsageId(),
                            memberId,
                            deviceNum,
                            purposeField.getText().trim()
                    );
                    appendOutput(equipmentOutputArea,
                            "Usage " + selected.getUsageId() + " updated.");
                    onRefreshUsage();
                } catch (NumberFormatException e) {
                    appendOutput(equipmentOutputArea, "Member ID and Device # must be numbers.");
                } catch (SQLException e) {
                    error(equipmentOutputArea, e);
                }
            }
            return null;
        });

        dialog.showAndWait();
    }

    @FXML
private void onRemoveUsage() {
    if (!ensureDao(equipmentOutputArea)) return;

    EquipmentUsage selected = usageTable.getSelectionModel().getSelectedItem();
    if (selected == null) {
        appendOutput(equipmentOutputArea, "Select a usage record to remove.");
        return;
    }

    Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
            "Remove usage ID " + selected.getUsageId() +
                    " (Member " + selected.getMemberId() +
                    ", Device " + selected.getDeviceNumber() + ")?",
            ButtonType.OK, ButtonType.CANCEL);
    confirm.setHeaderText("Confirm Usage Removal");
    confirm.showAndWait();

    if (confirm.getResult() != ButtonType.OK) {
        return;
    }

    try {
        dao.deleteEquipmentUsage(selected.getUsageId());
        appendOutput(equipmentOutputArea,
                "Usage " + selected.getUsageId() + " removed.");
        onRefreshUsage();
    } catch (SQLException e) {
        error(equipmentOutputArea, e);
    }
}


    @FXML
    private void onShowDeviceStatus() {
        if (!ensureDao(equipmentOutputArea)) return;
        Integer id = parseInt(deviceStatusIdField.getText(), equipmentOutputArea, "Device #");
        if (id == null) return;
        try {
            String status = dao.getDeviceStatus(id);
            deviceStatusResultLabel.setText("Status: " + status);
            appendOutput(equipmentOutputArea, "Device #" + id + " status: " + status);
        } catch (SQLException e) {
            error(equipmentOutputArea, e);
        }
    }

    @FXML
    private void onShowDeviceUsers() {
        Integer id = parseInt(deviceUsersIdField.getText(), equipmentOutputArea, "Device #");
        if (id == null) return;
        runWithStdoutCapture(equipmentOutputArea, () -> dao.showEquipmentUsers(id));
    }

    // ============================================================
    // Tab 3 - Grant & Publication Reporting
    // ============================================================

    @FXML private void onTop5Funded() {
        runWithStdoutCapture(reportingOutputArea, () -> dao.getTop5FundedProjects());
    }
    @FXML private void onTopMentor() {
        runWithStdoutCapture(reportingOutputArea, () -> dao.getTopMentorByMenteePubs());
    }
    @FXML private void onPubsByMajorYear() {
        runWithStdoutCapture(reportingOutputArea, () -> dao.getStudentPubsByMajorAndYear());
    }
    @FXML private void onTop3Years() {
        runWithStdoutCapture(reportingOutputArea, () -> dao.getTop3ProductiveYears());
    }
    @FXML private void onProjectsEndedBefore() {
        if (!ensureDao(reportingOutputArea)) return;
        LocalDate date = endedBeforeDatePicker.getValue();
        if (date == null) {
            appendOutput(reportingOutputArea, "Please select a date.");
            return;
        }
        runWithStdoutCapture(reportingOutputArea,
                () -> dao.getProjectsBeforeDate(date.toString()));
    }

    // ============================================================
    // Helpers
    // ============================================================

    /**
     * Several DAO methods print directly to System.out. Rather than rewriting
     * them, redirect stdout into a buffer for the duration of the call and
     * dump the captured text into the supplied TextArea.
     */
    private interface SqlAction { void run() throws SQLException; }

    private void runWithStdoutCapture(TextArea target, SqlAction action) {
        if (!ensureDao(target)) return;
        PrintStream original = System.out;
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        try (PrintStream tee = new PrintStream(buffer, true, StandardCharsets.UTF_8)) {
            System.setOut(tee);
            action.run();
        } catch (SQLException e) {
            System.setOut(original);
            error(target, e);
            return;
        } finally {
            System.setOut(original);
        }
        target.setText(buffer.toString(StandardCharsets.UTF_8));
    }

    private boolean ensureDao(TextArea target) {
        if (dao == null) {
            appendOutput(target, "Not connected to database.");
            return false;
        }
        return true;
    }

    private Integer parseInt(String raw, TextArea target, String field) {
        try {
            return Integer.parseInt(raw.trim());
        } catch (NumberFormatException e) {
            appendOutput(target, field + " must be a number.");
            return null;
        }
    }

    private void appendOutput(TextArea target, String line) {
        target.appendText(line + System.lineSeparator());
    }

    private void error(TextArea target, Exception e) {
        appendOutput(target, "Error: " + e.getMessage());
    }

    private void notImplemented(TextArea target, String operation) {
        appendOutput(target, "[" + operation + "] - not yet implemented in DAO.");
    }
}
