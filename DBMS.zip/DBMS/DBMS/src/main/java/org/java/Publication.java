package org.java;

public class Publication {
    private int pubId;
    private String title;
    private int year;
    private String venue;
    // Getters and Setters
}
