package org.java;

 import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

 import java.util.List;

public class DB {
    public static void main(String[] args) {
        // 1. Connection details (Update database name and password!)
        String url = "jdbc:sqlserver://localhost:1433;databaseName=ResearchLabManager;encrypt=true;trustServerCertificate=true;";
        String user = "sa";
        String password = "YourStrongPassword123!";

        // Use 'try-with-resources' to auto-close the connection when done
        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            System.out.println("Connection successful!");

            // 2. INITIALIZE the DAO by passing the connection
            LabManagerDAO dao = new LabManagerDAO(conn);

            // 3. RUN the methods
            System.out.println("--- Project Status ---");
            String status = dao.getProjectStatus(1); // Example ID
            System.out.println("Project 101 Status: " + status);

            System.out.println("\n--- Members for Grant ID 5 ---");
            List<String> members = dao.getMembersByGrant(1);
            for (String name : members) {
                System.out.println("Member: " + name);
            }

            System.out.println("\n--- Mentorship Relations ---");
            dao.printMentorshipByProject();
            //



                // --- 1. Equipment Status Check ---
                System.out.println("=== Checking Device Status ===");
                int deviceIdToCheck = 1; // Example: Device #1
                String statuss = dao.getDeviceStatus(deviceIdToCheck);
                System.out.println("Device #" + deviceIdToCheck + " is currently: " + statuss);

                // --- 2. Track Current Usage & Related Projects ---
                System.out.println("\n=== Current Users of Device #1 ===");
    /*
       This will show the member using the device AND
       the projects that member is currently assigned to.
    */
                dao.showEquipmentUsers(1);
            dao.getTop5FundedProjects();
            System.out.println();

            // 2. Most Productive Mentor
            dao.getTopMentorByMenteePubs();
            System.out.println();

            // 3. Publications by Student Major and Year
            dao.getStudentPubsByMajorAndYear();
            System.out.println();

            // 4. Projects ended before a specific date (Example: Jan 1, 2025)
            // Format must match 'YYYY-MM-DD'
            dao.getProjectsBeforeDate("2025-01-01");
            System.out.println();

            // 5. Three most productive years
            dao.getTop3ProductiveYears();

                // --- 3. Example of Adding New Usage (Remove if not needed) ---
    /*
    System.out.println("\n=== Registering New Equipment Usage ===");
    // Logic: Member #2 (Bob) starts using Device #2 for 'Data Collection'
    String insertUsage = "INSERT INTO UsageLogs (MemberID, DeviceNumber, Purpose) VALUES (2, 2, 'Data Collection')";
    try (Statement stmt = conn.createStatement()) {
        stmt.executeUpdate(insertUsage);
        System.out.println("New usage log created for Bob.");
    }
    */



            //

        } catch (SQLException e) {
           // System.err.println("Database error: " + e.getMessage());
           // e.printStackTrace();
        }
    }
}
